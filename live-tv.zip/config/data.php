<?php

return [
    'per_page' => 10,
    'content_type' => [
        'Movie',
        'Series',
    ]
];
