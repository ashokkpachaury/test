<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{

    protected $fillable = ['title', 'type', 'movie_ids', 'series_ids', 'status', 'is_highlight'];

    protected $appends = ['movies', 'series', 'totalItems'];
    protected $casts = [
        'movie_ids' => 'array',
        'series_ids' => 'array',
        'is_highlight' => 'boolean'
    ];
    protected $hidden = [
        'movie_ids',
        'series_ids',
        'is_highlight',
        'created_at',
        'updated_at'
    ];


    protected static function booted()
    {
        static::addGlobalScope('reselect', function ($query) {
            // add these fields to the came case
            return $query->select(
                '*',
                'movie_ids as movieIds',
                'series_ids as serieIds ',
                'is_highlight as isHighlight',
                'created_at as createdAt',
                'updated_at as updatedAt'
            );
        });
    }


    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    public function getMovieIdsAttribute($value)
    {
        return json_decode($value) ?? [];
    }

    public function getSeriesIdsAttribute($value)
    {
        return json_decode($value) ?? [];
    }

    public function getMoviesAttribute($value)
    {
        $items= Movies::query()->whereIn('id', $this->movie_ids)
//            ->where('status', 1)
        ;
        if (request()->page) {
            return $items->paginate(config('data.per_page'))->items();
        } else {
            return $items->get();
        }
    }

    public function getSeriesAttribute($value)
    {
        $items = Series::query()->whereIn('id', $this->series_ids)
//            ->where('status', 1)
        ;
        if (request()->page) {
           return $items->paginate(config('data.per_page'))->items();
        } else {
            return $items->get();
        }
    }

    public function getTotalItemsAttribute($value)
    {
        return $this->movies->count() + $this->series->count();
    }


}
