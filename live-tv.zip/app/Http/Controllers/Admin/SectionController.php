<?php

namespace App\Http\Controllers\Admin;

use App\LiveTV;
use App\Section;
use App\Slider;
use App\Sports;
use Auth;
use App\User;
use App\HomeSection;
use App\Language;
use App\Movies;
use App\Series;

use App\Http\Requests;
use Illuminate\Http\Request;
use Session;
use Intervention\Image\Facades\Image;

class SectionController extends MainAdminController

{
    public function index()
    {
        if (Auth::User()->usertype != "Admin" and Auth::User()->usertype != "Sub_Admin") {
            \Session::flash('flash_message', trans('words.access_denied'));
            return redirect('dashboard');
        }
        $page_title = trans('words.home_section');
        $items = Section::orderBy('id', 'DESC')->paginate(10);

        return view('admin.home-section.index', compact('page_title', 'items'));
    }

    public function create(Request $request)
    {
        if (Auth::User()->usertype != "Admin" and Auth::User()->usertype != "Sub_Admin") {
            \Session::flash('flash_message', trans('words.access_denied'));
            return redirect('dashboard');
        }
        $id = $request->id;
        if ($id) {
            $item = Section::query()->findOrFail($id);
        } else {
            $item = new Section();
        }

        $page_title = trans('words.home_section');

        $language_list = Language::orderBy('language_name')->get();
        $movies_list = Movies::orderBy('id', 'DESC')->get();
        $series_list = Series::orderBy('id', 'DESC')->get();
        return view('admin.home-section.form', compact('page_title', 'language_list', 'movies_list', 'series_list', 'item'));
    }


    public function store(Request $request)
    {
        $id = $request->id;
        $data = $request->validate([
            'title' => 'required',
            'type' => 'required',
            'movie_ids' => 'array',
            'series_ids' => 'array',
            'status' => 'required',
        ]);
        $data['is_highlight'] = $request->boolean('is_highlight');

        if ($data['type'] == 'Movie') {
            $data['series_ids'] = [];
        } else {
            $data['movie_ids'] = [];
        }


        if ($id) {
            $item = Section::query()->findOrFail($id);
        } else {
            $item = new Section();
        }
        $item->fill($data);
        $item->save();

        if ($id) {
            \Session::flash('flash_message', trans('words.successfully_updated'));
            return back();
        }
        \Session::flash('flash_message', trans('words.added'));
        return redirect()->route('home-section.index');
    }


    public function delete($slider_id)
    {
        if (Auth::User()->usertype == "Admin" or Auth::User()->usertype == "Sub_Admin") {

            $slider_obj = Slider::findOrFail($slider_id);
            $slider_obj->delete();

            \Session::flash('flash_message', trans('words.deleted'));
            return redirect()->back();
        } else {
            \Session::flash('flash_message', trans('words.access_denied'));
            return redirect('admin/dashboard');

        }
    }

    public function destory($id)
    {
        $item = Section::query()->findOrFail($id);
        $item->delete();
        \Session::flash('flash_message', trans('Successfully Deleted'));
        return back();


    }


}
