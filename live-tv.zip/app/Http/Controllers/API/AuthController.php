<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
       $data = $request->validate([
            'email' => 'email|required',
            'password' => 'required',
        ]);
        $user = User::query()->where('email', $data['email'])->first();
        if (!Hash::check($data['password'], $user->password)){
            return response([
                'status' => false,
                'data' => null,
                'msg' => 'Email or password incorrect'
            ]);
        }
        return response([
            'status' => true,
            'data' => ['token' => $user->createToken($request->device ?? 'web')->plainTextToken, 'user' => $user],
            'msg' => 'Login successful'
        ]);

    }
}
